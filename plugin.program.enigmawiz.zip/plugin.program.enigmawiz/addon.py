import sys
from resources.lib.modules.plugin import router

if __name__=='__main__':
    router(sys.argv[2][1:])