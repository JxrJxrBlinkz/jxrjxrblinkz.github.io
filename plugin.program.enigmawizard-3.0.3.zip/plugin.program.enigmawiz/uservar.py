import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://team-enigma.xyz/builds/enigma.zip?dl=1'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
