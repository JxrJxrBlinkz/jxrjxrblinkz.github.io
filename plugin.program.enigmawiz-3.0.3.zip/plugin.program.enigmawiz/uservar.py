import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'http://team-enigma.xyz/builds.txt/build.txt'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://team-enigma.xyz/builds.txt/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
