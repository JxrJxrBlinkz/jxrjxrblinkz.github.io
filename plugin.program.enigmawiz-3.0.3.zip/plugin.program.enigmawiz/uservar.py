import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://team-enigma.xyz/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
