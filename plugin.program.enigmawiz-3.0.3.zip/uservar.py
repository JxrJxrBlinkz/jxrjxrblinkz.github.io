import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://github.com/JxrJxrBlinkz/jxrjxrblinkz.github.io/blob/master/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://github.com/JxrJxrBlinkz/jxrjxrblinkz.github.io/blob/master/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
