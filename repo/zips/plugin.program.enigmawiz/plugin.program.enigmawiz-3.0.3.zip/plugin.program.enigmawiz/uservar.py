import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'http://team-enigma.xyz/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
