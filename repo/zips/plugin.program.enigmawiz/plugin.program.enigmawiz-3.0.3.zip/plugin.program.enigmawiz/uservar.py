import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://github.com/JxrJxrBlinkz/jxrjxrblinkz.github.io/blob/master/repo/plugin.program.enigmawiz/resources/texts/builds.json'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://github.com/JxrJxrBlinkz/jxrjxrblinkz.github.io/blob/master/repo/plugin.program.enigmawiz/resources/texts/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
