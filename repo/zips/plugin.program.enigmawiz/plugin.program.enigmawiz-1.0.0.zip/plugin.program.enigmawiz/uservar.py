import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://team-enigma.xyz/builds.txt'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://team-enigma.xyz/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
