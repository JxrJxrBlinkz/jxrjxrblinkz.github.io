import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://jxrjxrblinkz.github.io/build.txt'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://jxrjxrblinkz.github.io/notify.txt'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
