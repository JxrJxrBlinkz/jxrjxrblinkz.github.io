import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://github.com/JxrJxrBlinkz/jxrjxrblinkz.github.io/blob/master/repo/plugin.program.enigmawiz/resources/texts/builds.xml'

'''#####-----Notifications File-----#####'''
notify_url  = 'http://'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever']
